package com.example.moneytracker

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class edit_education : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_education)
    }
}